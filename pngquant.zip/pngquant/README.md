python PngCompress.py 
